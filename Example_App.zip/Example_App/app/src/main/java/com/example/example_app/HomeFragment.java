package com.example.example_app;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment implements View.OnClickListener {


    private Button btn_add , btn_view, btn_update, btn_delete;

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        btn_add = view.findViewById(R.id.btnadd);
        btn_add.setOnClickListener(this);

        btn_view = view.findViewById(R.id.btnview);
        btn_view.setOnClickListener(this);

        btn_update = view.findViewById(R.id.btnupdate);
        btn_update.setOnClickListener(this);

        btn_delete = view.findViewById(R.id.btndelete);
        btn_delete.setOnClickListener(this);


        return view;
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){

            case R.id.btnadd:
                MainActivity.fragmentManager.beginTransaction().replace(R.id.fragment_container, new AddUserFragment()).addToBackStack(null).commit();
                break;

            case R.id.btnview:
                MainActivity.fragmentManager.beginTransaction().replace(R.id.fragment_container, new ShowUserFragment()).addToBackStack(null).commit();
                break;

            case R.id.btndelete:
                MainActivity.fragmentManager.beginTransaction().replace(R.id.fragment_container, new DeleteUserFragment()).addToBackStack(null).commit();
                break;

            case R.id.btnupdate:
                MainActivity.fragmentManager.beginTransaction().replace(R.id.fragment_container, new UpdateUserFragment() ).addToBackStack(null).commit();
                break;

        }
    }
}
