package com.example.example_app;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class ShowUserFragment extends Fragment {

    EditText ed_display;
    TextView tv_display;
    Button btn_show_user;

    public ShowUserFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_show_user, container, false);

        ed_display = view.findViewById(R.id.ed_display_info);
        tv_display = view.findViewById(R.id.tv_display_info);
        btn_show_user = view.findViewById(R.id.btn_show);
        btn_show_user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                List<User> users = MainActivity.myAppDatabase.myDao().getUser();
                String info = "";

                int id = Integer.parseInt(ed_display.getText().toString());

                for( User usr : users)
                {
                    int id1 = usr.getId();
                    String name = usr.getName();
                    String email = usr.getEmail();

                    if( id == id1) {
                        info = info + "\n\n" + "ID" + id + "\n Name :" + name + "\n Email :" + email;
                        tv_display.setText(info);
                        break;
                    }
                    else {
                        Toast.makeText(getActivity(), "ID is not Present in a Database", Toast.LENGTH_SHORT).show();
                    }
                }



            }
        });

        return view;
    }

}
