package com.example.example_app;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EdgeEffect;
import android.widget.EditText;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class UpdateUserFragment extends Fragment {

    private EditText ed_id , ed_name , ed_email ;
    private Button btn_update ;


    public UpdateUserFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_update_user, container, false);

        ed_id = view.findViewById(R.id.ed_userid);
        ed_name = view.findViewById(R.id.ed_username);
        ed_email = view.findViewById(R.id.ed_useremail);
        btn_update = view.findViewById(R.id.btnupdate);

        btn_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int id = Integer.parseInt(ed_id.getText().toString());
                String name = ed_name.getText().toString();
                String email = ed_email.getText().toString();

                User user = new User();
                user.setId(id);
                user.setName(name);
                user.setEmail(email);

                MainActivity.myAppDatabase.myDao().updateUser(user);
                Toast.makeText(getActivity(), "Data Updated Successfully.", Toast.LENGTH_SHORT).show();

            }
        });

        return view;
    }

}
